import React, { useState } from 'react';
// 1. ADD THE IMPORT STATEMENT HERE
import './WeatherApp.css'; 
// Also remove the import to App.css if it was there before

const WeatherApp = () => {
    const [city, setCity] = useState("");
    const [weather, setWeather] = useState(null);
    const [error, setError] = useState(null);

    const API_KEY = "36eec97273895a425125a919badbe1ca";

    const getWeather = async () => {
        setError(null);
        setWeather(null);

        try {
            const res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`)

            const data = await res.json();

            if (data.cod === 200) {
                setWeather(data);
            }
            else {
                setWeather(null);
                // 2. Display the error message instead of an alert
                setError("City not found. Please try again.");
            }
        }
        catch (err) {
            setError("A network error occurred. Please try again.");
            console.error(err);
        }
    }

    return (
        // 3. APPLY THE MAIN CONTAINER CLASS
        <div className="weather-app-container"> 
            <h2 className="app-title">Weather App</h2>
            <div className="search-box">
                {/* 4. APPLY INPUT AND BUTTON CLASSES */}
                <input
                    type="text"
                    className="city-input"
                    placeholder="Enter city name"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                />
                <button 
                    onClick={getWeather} 
                    className="search-button">
                    <i className="fas fa-search"></i> Search
                </button>
            </div>

            {/* 5. DISPLAY ERROR MESSAGE */}
            {error && <p className="error-message">{error}</p>}

            {/* 6. APPLY WEATHER CARD CLASSES */}
            {weather && (
                <div className="weather-card">
                    <h3 className="city-name">{weather.name}</h3>
                    <p className="description-text">{weather.weather[0].description}</p>
                    
                    <div className="temp-section">
                        <p className="temperature">{Math.round(weather.main.temp)}°C</p>
                    </div>

                    <div className="details-grid">
                        <div className="detail-item">
                            <i className="fas fa-wind"></i>
                            <p>Wind Speed</p>
                            <p className="value">{weather.wind.speed} m/s</p>
                        </div>
                        <div className="detail-item">
                            <i className="fas fa-tint"></i>
                            <p>Humidity</p>
                            <p className="value">{weather.main.humidity}%</p>
                        </div>
                        <div className="detail-item">
                            <i className="fas fa-tachometer-alt"></i>
                            <p>Pressure</p>
                            <p className="value">{weather.main.pressure} hPa</p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default WeatherApp;